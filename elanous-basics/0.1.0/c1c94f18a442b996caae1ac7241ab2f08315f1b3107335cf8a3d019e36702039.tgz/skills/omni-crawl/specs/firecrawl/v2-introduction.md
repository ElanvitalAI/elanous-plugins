> ## Documentation Index
> Fetch the complete documentation index at: https://docs.firecrawl.dev/llms.txt
> Use this file to discover all available pages before exploring further.

# Introduction

> Firecrawl API Reference (v2)

<Note>
  **For AI agents:** Use [llms.txt](/llms.txt) for a full index of all documentation.
</Note>

The Firecrawl API gives you programmatic access to web data. All endpoints share a common base URL, authentication scheme, and response format described on this page.

## Features

<CardGroup cols={3}>
  <Card title="Scrape" icon="markdown" href="/api-reference/endpoint/scrape" color="FF713C">
    Extract content from any webpage in markdown or json format.
  </Card>

  <Card title="Parse" icon="markdown" href="/api-reference/endpoint/parse" color="FF713C">
    Upload files and parse them into markdown or other formats.
  </Card>

  <Card title="Crawl" icon="spider" href="/api-reference/endpoint/crawl-post" color="FF713C">
    Crawl entire websites and get content from all pages.
  </Card>

  <Card title="Map" icon="map" href="/api-reference/endpoint/map" color="FF713C">
    Get a complete list of URLs from any website quickly and reliably.
  </Card>

  <Card title="Search" icon="magnifying-glass" href="/api-reference/endpoint/search" color="FF713C">
    Search the web and get full page content in any format.
  </Card>
</CardGroup>

## Agentic Features

<CardGroup cols={3}>
  <Card title="Agent" icon="robot" href="/api-reference/endpoint/agent" color="FF713C">
    Autonomous web data gathering powered by AI.
  </Card>

  <Card title="Browser" icon="browser" href="/api-reference/endpoint/browser-create" color="FF713C">
    Create and control browser sessions for interactive web tasks.
  </Card>
</CardGroup>

## Base URL

All requests use the following base URL:

```bash theme={null}
https://api.firecrawl.dev
```

## Authentication

Every request requires an `Authorization` header with your API key:

```bash theme={null}
Authorization: Bearer fc-YOUR-API-KEY
```

Include this header in all API calls. You can find your API key in the [Firecrawl dashboard](https://www.firecrawl.dev/app/api-keys).

If you are an agent without an API key, start with [Get credentials](/ai-onboarding#get-credentials). If your platform supports WorkOS ID-JAG, use [`auth.md`](https://www.firecrawl.dev/auth.md) for registration instructions.

<CodeGroup>
  ```bash cURL theme={null}
  curl -X POST "https://api.firecrawl.dev/v2/scrape" \
    -H "Authorization: Bearer fc-YOUR-API-KEY" \
    -H "Content-Type: application/json" \
    -d '{"url": "https://example.com"}'
  ```

  ```python Python theme={null}
  from firecrawl import Firecrawl

  firecrawl = Firecrawl(api_key="fc-YOUR-API-KEY")

  result = firecrawl.scrape("https://example.com")
  ```

  ```js Node theme={null}
  import { Firecrawl } from 'firecrawl';

  const firecrawl = new Firecrawl({ apiKey: "fc-YOUR-API-KEY" });

  const result = await firecrawl.scrape('https://example.com');
  ```
</CodeGroup>

## Response codes

Firecrawl uses conventional HTTP status codes to indicate the outcome of your requests. Codes in the `2xx` range indicate success, `4xx` codes indicate client errors, and `5xx` codes indicate server errors.

See [Errors](/api-reference/errors) for the full reference, including the `error` string returned for each failure mode, retry guidance, and a copy-pasteable backoff snippet.

## 429 responses

When you exceed your plan's rate or concurrency limits, the API returns a `429` status code. See [Rate Limits](/rate-limits) for per-plan limits and [Errors](/api-reference/errors) for retry guidance.
